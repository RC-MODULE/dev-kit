//----------------------------------------------------------------------------//
//                                                                            //
//                           MC12101 board examples                           //
//                                                                            //
//                                Demo program                                //
//                   that exchange arrays with NM on board.                   //
//                            NM part of program.                             //
//                                                                            //
//                  2016 (c) RC Module Inc., Moscow, Russia                   //
//                                                                            //
//----------------------------------------------------------------------------//

#include "mc12101load_nm.h"

typedef unsigned int WORD32;

const WORD32 Length = 0x100;
WORD32 AddrStore[Length];
WORD32 AddrLoad[Length];

int main()
{
	WORD32 Fill = 1;

	// Initial fill
	for (int i = 0; i < Length; i++)
		AddrStore[i] = Fill;

	ncl_hostSyncArray(1, AddrStore, Length, NULL, NULL);

	while (1)
	{
		if (ncl_hostSyncArray(2, AddrLoad, Length, NULL, NULL) == 17)
			break;

		// Time for host work

		if (ncl_hostSync(3) == 17)
			break;

		for (int i = 0; i < Length; i++)
			AddrStore[i] = AddrLoad[i];
	}

	return 0;
}
