//----------------------------------------------------------------------------//
//                                                                            //
//                           MC12101 board examples                           //
//                                                                            //
//                                Demo program                                //
//                   that exchange arrays with NM on board.                   //
//                            PC part of program.                             //
//                                                                            //
//                  2016 (c) RC Module Inc., Moscow, Russia                   //
//                                                                            //
//----------------------------------------------------------------------------//

#include <iostream>
#include <stdlib.h>

#include "mc12101load.h"

using namespace std;

const char *NM_PART_FILE_NAME = "nm_part.abs";

int main()
{
	PL_Board *board;
	PL_Access *access;
	unsigned int boardCount;

	if (PL_GetBoardCount(&boardCount) != PL_OK)
	{
		cout << "ERROR: Failed open driver!\n";
		exit(1);
	}

	if (boardCount < 1)
	{
		cout << "ERROR: Failed find board!\n";
		exit(1);
	}

	if (PL_GetBoardDesc(0, &board) != PL_OK)
	{
		cout << "ERROR: Failed open board!\n";
		exit(1);
	}

	if (PL_GetAccess(board, 0, &access) != PL_OK)
	{
		cout << "ERROR: Failed access processor!\n";
		PL_CloseBoardDesc(board);
		exit(1);
	}

	if (PL_LoadProgramFile(access, NM_PART_FILE_NAME) != PL_OK)
	{
		cout << NM_PART_FILE_NAME << " :: ERROR: Failed load program into board!\n";
		PL_CloseAccess(access);
		PL_CloseBoardDesc(board);
		exit(1);
	}

	PL_Word Length = 0;
	PL_Word *Buffer = NULL;
	PL_Addr AddrLoad = 0;
	PL_Addr AddrStore = 0;
	int syncValue = 0;

	// Receive input array address
	if (PL_SyncArray(access, 0, 0, 0, &syncValue, &AddrLoad, &Length) != PL_OK)
	{
		cout << "ERROR: ERROR in sync 1!\n";
		PL_CloseAccess(access);
		PL_CloseBoardDesc(board);
		exit(1);
	}

	if (syncValue != 1)
	{
		cout << "ERROR: Wrong value in sync 1!\n";
		PL_CloseAccess(access);
		PL_CloseBoardDesc(board);
		exit(1);
	}

	try
	{
		Buffer = new PL_Word[Length];
	}
	catch (...)
	{
		cout << "ERROR: Insufficient memory!\n";
		PL_CloseAccess(access);
		PL_CloseBoardDesc(board);
		exit(1);
	}

	for (int i = 1; i <= 10; i++)
	{
		// Sync for receive array and address of output array
		if (PL_SyncArray(access, 1, 0, 0, &syncValue, &AddrStore, NULL) != PL_OK)
		{
			cout << "ERROR: ERROR in sync 2!\n";
			delete[] Buffer;
			PL_CloseAccess(access);
			PL_CloseBoardDesc(board);
			exit(1);
		}

		if (syncValue != 2)
		{
			cout << "ERROR: Wrong value in sync 2!\n";
			delete[] Buffer;
			PL_CloseAccess(access);
			PL_CloseBoardDesc(board);
			exit(1);
		}

		// Receive array
		if (PL_ReadMemBlock(access, Buffer, AddrLoad, Length) != PL_OK)
		{
			cout << "ERROR: Failed receive array!\n";
			delete[] Buffer;
			PL_CloseAccess(access);
			PL_CloseBoardDesc(board);
			exit(1);
		}

		cout << "Verify number " << i << "...\n";

		for (int j = 0; j < Length; j++)
		{
			if (Buffer[j] != i)
			{
				cout << "ERROR: Bad buffer[" << j << "] on step " << i << "!\n";
				delete[] Buffer;
				PL_CloseAccess(access);
				PL_CloseBoardDesc(board);
				exit(1);
			}

			// New fill of array
			Buffer[j] = i + 1;
		}

		// Send array
		if (PL_WriteMemBlock(access, Buffer, AddrStore, Length) != PL_OK)
		{
			cout << "ERROR: Failed send array!\n";
			delete[] Buffer;
			PL_CloseAccess(access);
			PL_CloseBoardDesc(board);
			exit(1);
		}

		// Sync for send array
		if (PL_Sync(access, 2, &syncValue) != PL_OK)
		{
			cout << "ERROR: ERROR in sync 3!\n";
			delete[] Buffer;
			PL_CloseAccess(access);
			PL_CloseBoardDesc(board);
			exit(1);
		}

		if (syncValue != 3)
		{
			cout << "ERROR: Wrong value in sync 3!\n";
			delete[] Buffer;
			PL_CloseAccess(access);
			PL_CloseBoardDesc(board);
			exit(1);
		}
	}

	delete[] Buffer;

	// Sync for end program
	if (PL_Sync(access, 17, NULL) != PL_OK)
	{
		cout << "ERROR: ERROR in sync 4!\n";
		PL_CloseAccess(access);
		PL_CloseBoardDesc(board);
		exit(1);
	}

	PL_CloseAccess(access);
	PL_CloseBoardDesc(board);

	cout << "Test Ok.\n";
	return 0;
}
