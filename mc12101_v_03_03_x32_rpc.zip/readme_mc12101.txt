Support kit for MC121.01 board

1. To install software support for MC121.01 board copy all files into the
working directory.

2. To build programs for MC121.01 board use mc12101lib_nm.lib library.
Make sure, that this library is linked before standard libc4.lib library.
Example:
  nmcc test.cpp mc12101lib_nm.lib           // Correct
  nmcc test.cpp mc12101lib_nm.lib libc4.lib // Correct
  nmcc test.cpp libc4.lib mc12101lib_nm.lib // Incorrect

3. For more detailed information see doc\mc12101sk-manual.doc.